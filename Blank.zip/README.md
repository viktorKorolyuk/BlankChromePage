# BlankChromePage
Replaces chrome "newtab" with a white page.